The details of this sample app is available in [1].

[1] 
