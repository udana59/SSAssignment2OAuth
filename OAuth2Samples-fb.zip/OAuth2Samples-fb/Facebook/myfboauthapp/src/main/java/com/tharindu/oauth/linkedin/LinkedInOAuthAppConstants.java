package com.tharindu.oauth.linkedin;

public class LinkedInOAuthAppConstants {

    public static final String TOKEN_ENDPOINT = "https://graph.facebook.com/oauth/access_token";
    public static final String GRANT_TYPE = "authorization_code";
    public static final String REDIRECT_URI = "https://localhost:8443/mylinkedinoauthapp/callback";
    public static final String CLIENT_ID = "494738091675788";
    public static final String CLIENT_SECRET = "f1e0055dcdef686a0502e6cd2f94d954";
}
